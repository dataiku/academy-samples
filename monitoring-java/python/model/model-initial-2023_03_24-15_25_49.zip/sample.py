import os
from pprint import pprint
from dataikuscoring import load_model


path_to_export = os.path.dirname(os.path.realpath(__file__))

# Load the model from current export path
model = load_model(path_to_export)

# The model provides a simple api similar to scikit-learn with:
# * model.predict to get scoring for a given input data
# * model.predict_proba to get probabilities in case of classification
#
# The accepted format for input data can be either:
# * pandas.DataFrame
# * List of dictionnaries
# * 2D numpy array
# * List of List
#
# The first dimension corresponds to observations
data_to_score = [
    {
        "attack": 100
        ,"base_egg_steps": 5120
        ,"base_happiness": 70
        ,"base_total": 625
        ,"defense": 123
        ,"experience_growth": 1059860
        ,"height_m": 2.0
        ,"hp": 80
        ,"name": "Venusaur"
        ,"percentage_male": 88.1
        ,"sp_attack": 122
        ,"sp_defense": 120
        ,"speed": 80
        ,"weight_kg": 100.0
    }
    ,{
        "attack": 52
        ,"base_egg_steps": 5120
        ,"base_happiness": 70
        ,"base_total": 309
        ,"defense": 43
        ,"experience_growth": 1059860
        ,"height_m": 0.6
        ,"hp": 39
        ,"name": "Charmander"
        ,"percentage_male": 88.1
        ,"sp_attack": 60
        ,"sp_defense": 50
        ,"speed": 65
        ,"weight_kg": 8.5
    }
]


# For instance the following will output a numpy array containing the predictions for each
# observation

predict_result = model.predict(data_to_score)
print(" \nOutput of model.predict():\n")
pprint(predict_result)

# In case of classification the following will output a dictionnary of numpy array with
# probabilities for each class
predict_proba_result = model.predict_proba(data_to_score)
print(" \nOutput of model.predict_proba():\n")
pprint(predict_proba_result)
